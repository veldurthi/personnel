SELECT *
FROM sys.dm_pdw_nodes
GO

SELECT *
FROM sys.pdw_distributions
GO